<?php
/**
 * Email Sending Functions – powered by PHPMailer (SMTP)
 *
 * ─────────────────────────────────────────────────────
 *  HOW TO SET UP
 * ─────────────────────────────────────────────────────
 *  1. Install PHPMailer once from the api/ directory:
 *       composer require phpmailer/phpmailer
 *
 *  2. Fill in the constants below with your SMTP provider.
 *
 *  ── Gmail ────────────────────────────────────────────
 *     SMTP_HOST = 'smtp.gmail.com'
 *     SMTP_PORT = 587
 *     SMTP_USER = 'you@gmail.com'
 *     SMTP_PASS = '<16-char App Password>'   ← NOT your normal password
 *     (Enable 2-Step Verification, then generate an App Password at
 *      https://myaccount.google.com/apppasswords)
 *
 *  ── Outlook / Microsoft 365 ──────────────────────────
 *     SMTP_HOST = 'smtp.office365.com'
 *     SMTP_PORT = 587
 *     SMTP_USER = 'you@yourdomain.com'
 *     SMTP_PASS = '<your password>'
 *
 *  ── SendGrid ─────────────────────────────────────────
 *     SMTP_HOST = 'smtp.sendgrid.net'
 *     SMTP_PORT = 587
 *     SMTP_USER = 'apikey'
 *     SMTP_PASS = '<your SendGrid API key>'
 *
 *  ── Mailgun ──────────────────────────────────────────
 *     SMTP_HOST = 'smtp.mailgun.org'
 *     SMTP_PORT = 587
 *     SMTP_USER = 'postmaster@mg.yourdomain.com'
 *     SMTP_PASS = '<Mailgun SMTP password>'
 * ─────────────────────────────────────────────────────
 */

// ── SMTP credentials are loaded from api/config.php ──────────────────────────
// Do NOT hardcode credentials here. Edit api/config.php or set environment
// variables (DB_HOST, SMTP_USER, SMTP_PASS, etc.) on your server.
require_once __DIR__ . '/config.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


require_once __DIR__ . '/vendor/phpmailer/Exception.php';
require_once __DIR__ . '/vendor/phpmailer/SMTP.php';
require_once __DIR__ . '/vendor/phpmailer/PHPMailer.php';

/**
 * Create a pre-configured PHPMailer instance.
 * Shared by both send functions below.
 */
function _makeMailer(): PHPMailer {
    $mail = new PHPMailer(true);   // true = throw exceptions on error

    $mail->isSMTP();
    $mail->Host       = SMTP_HOST;
    $mail->SMTPAuth   = true;
    $mail->Username   = SMTP_USER;
    $mail->Password   = SMTP_PASS;
    $mail->SMTPSecure = (SMTP_PORT === 465) ? PHPMailer::ENCRYPTION_SMTPS
                                            : PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = SMTP_PORT;

    $mail->setFrom(FROM_EMAIL, FROM_NAME);
    $mail->isHTML(true);
    $mail->CharSet = 'UTF-8';

    return $mail;
}

/** Send a password-reset link to $toEmail. */
function sendResetEmail(string $toEmail, string $resetLink, string $token): bool {
    try {
        $mail = _makeMailer();
        $mail->addAddress($toEmail);
        $mail->Subject = 'Password Reset Request – Library Management System';

        $mail->Body = <<<HTML
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .email-container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #2c3e50; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }
                .content { padding: 20px; background: #f9f9f9; border: 1px solid #ddd; border-top: none; }
                .button { background: #27ae60; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 20px 0; }
                .footer { font-size: 12px; color: #888; margin-top: 20px; border-top: 1px solid #ddd; padding-top: 10px; }
                .warning { color: #e74c3c; font-size: 12px; margin-top: 10px; }
            </style>
        </head>
        <body>
            <div class="email-container">
                <div class="header"><h2>Password Reset Request</h2></div>
                <div class="content">
                    <p>Hello,</p>
                    <p>We received a request to reset your password for the Library Management System.
                       Click the button below to reset your password:</p>
                    <a href="$resetLink" class="button">Reset Password</a>
                    <p>Or copy and paste this link in your browser:</p>
                    <p><small>$resetLink</small></p>
                    <p class="warning">This link will expire in 1 hour.</p>
                    <p>If you didn't request a password reset, please ignore this email.</p>
                    <p>Best regards,<br>Library Management System Team</p>
                </div>
                <div class="footer">
                    <p>&copy; 2026 Platonian's Library Management System. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
HTML;

        $mail->AltBody = "Reset your password by visiting this link (expires in 1 hour):\n$resetLink";

        $mail->send();
        return true;

    } catch (Exception $e) {
        error_log('sendResetEmail failed for ' . $toEmail . ': ' . $e->getMessage());
        return false;
    }
}

/** Notify $toEmail that their password was changed. */
function sendPasswordChangedEmail(string $toEmail): bool {
    try {
        $mail = _makeMailer();
        $mail->addAddress($toEmail);
        $mail->Subject = 'Password Changed Successfully – Library Management System';

        $mail->Body = <<<HTML
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .email-container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #2c3e50; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }
                .content { padding: 20px; background: #f9f9f9; border: 1px solid #ddd; border-top: none; }
                .success { color: #27ae60; }
                .footer { font-size: 12px; color: #888; margin-top: 20px; border-top: 1px solid #ddd; padding-top: 10px; }
            </style>
        </head>
        <body>
            <div class="email-container">
                <div class="header"><h2>Password Changed Successfully</h2></div>
                <div class="content">
                    <p>Hello,</p>
                    <p><span class="success">&#10003; Your password has been changed successfully.</span></p>
                    <p>If you didn't make this change, please contact the administrator immediately.</p>
                    <p>Best regards,<br>Library Management System Team</p>
                </div>
                <div class="footer">
                    <p>&copy; 2026 Platonian's Library Management System. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
HTML;

        $mail->AltBody = 'Your BookTrack password was changed. If this wasn\'t you, contact the administrator immediately.';

        $mail->send();
        return true;

    } catch (Exception $e) {
        error_log('sendPasswordChangedEmail failed for ' . $toEmail . ': ' . $e->getMessage());
        return false;
    }
}
?>
