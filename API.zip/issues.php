<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

require_once 'db.php';

try {
    $db = new Database();
    $pdo = $db->getPDO();
    $method = $_SERVER['REQUEST_METHOD'];

    $input = json_decode(file_get_contents('php://input'), true) ?: [];

    if ($method === 'POST') {
        /* Create new issue (book checkout) */
        $book_id = isset($input['book_id']) ? intval($input['book_id']) : 0;
        $member_id = isset($input['member_id']) ? intval($input['member_id']) : 0;
        $issue_date = isset($input['issue_date']) ? trim($input['issue_date']) : date('Y-m-d H:i:s');
        $due_date = isset($input['due_date']) ? trim($input['due_date']) : date('Y-m-d', strtotime('+14 days'));
        $book_title = isset($input['book_title']) ? trim($input['book_title']) : '';
        $author = isset($input['author']) ? trim($input['author']) : '';
        $member_name = isset($input['member_name']) ? trim($input['member_name']) : '';

        if (!$book_id || !$member_id) {
            http_response_code(400);
            ob_end_clean();

            echo json_encode(['success' => false, 'message' => 'Book ID and member ID are required']);
            exit;
        }

        /* Generate issue ID in format IS-### */
        $stmt = $pdo->prepare("SELECT id FROM issues ORDER BY id DESC LIMIT 1");
        $stmt->execute();
        $lastIssue = $stmt->fetch(PDO::FETCH_ASSOC);
        $maxNum = 0;
        if ($lastIssue && preg_match('/IS-(\d+)/', $lastIssue['id'], $matches)) {
            $maxNum = intval($matches[1]);
        }
        $newId = 'IS-' . str_pad($maxNum + 1, 3, '0', STR_PAD_LEFT);

        $stmt = $pdo->prepare('INSERT INTO issues (id, book_id, member_id, book_title, author, member_name, issue_date, due_date, status, renewals, `condition`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([$newId, $book_id, $member_id, $book_title, $author, $member_name, $issue_date, $due_date, 'Active', 0, 'Good']);

        ob_end_clean();


        echo json_encode(['success' => true, 'message' => 'Book issued successfully', 'id' => $newId]);
        exit;
    }

    if ($method === 'PATCH') {
        /* Update issue (renewals, returns, etc.) */
        $id = isset($input['id']) ? trim($input['id']) : '';
        if (!$id) {
            http_response_code(400);
            ob_end_clean();

            echo json_encode(['success' => false, 'message' => 'Issue ID is required']);
            exit;
        }

        $updates = [];
        $params = [];

        if (isset($input['due_date'])) {
            $updates[] = 'due_date = ?';
            $params[] = trim($input['due_date']);
        }
        if (isset($input['status'])) {
            $updates[] = 'status = ?';
            $params[] = trim($input['status']);
        }
        if (isset($input['renewals'])) {
            $updates[] = 'renewals = ?';
            $params[] = intval($input['renewals']);
        }
        if (isset($input['return_date'])) {
            $updates[] = 'return_date = ?';
            $params[] = trim($input['return_date']);
        }
        if (isset($input['condition'])) {
            $updates[] = '`condition` = ?';
            $params[] = trim($input['condition']);
        }

        if (count($updates) === 0) {
            http_response_code(400);
            ob_end_clean();

            echo json_encode(['success' => false, 'message' => 'Nothing to update']);
            exit;
        }

        $params[] = $id;
        $sql = 'UPDATE issues SET ' . implode(', ', $updates) . ' WHERE id = ?';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        ob_end_clean();


        echo json_encode(['success' => true, 'message' => 'Issue updated successfully']);
        exit;
    }

    if ($method === 'DELETE') {
        /* Delete issue record */
        $id = isset($input['id']) ? trim($input['id']) : '';
        if (!$id) {
            http_response_code(400);
            ob_end_clean();

            echo json_encode(['success' => false, 'message' => 'Issue ID is required']);
            exit;
        }

        $stmt = $pdo->prepare('DELETE FROM issues WHERE id = ?');
        $stmt->execute([$id]);

        ob_end_clean();


        echo json_encode(['success' => true, 'message' => 'Issue deleted successfully']);
        exit;
    }

    http_response_code(405);
    ob_end_clean();

    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
} catch (Exception $e) {
    http_response_code(500);
    ob_end_clean();

    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
    exit;
}
?>
