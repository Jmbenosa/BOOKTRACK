<?php
/* Suppress any PHP notices/warnings from polluting the JSON output */
ini_set('display_errors', '0');
error_reporting(0);
ob_start();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

require_once 'db.php';

try {
    $db = new Database();
    $pdo = $db->getPDO();

    $books   = $pdo->query('SELECT id, isbn, title, author, category, shelf, copies, available, status, is_lost, is_damaged FROM books ORDER BY title ASC')->fetchAll(PDO::FETCH_ASSOC);
    $members = $pdo->query('SELECT id, member_ref, name, email, phone, type, join_date, address, sid, grade, section, active, overdue, total_issued FROM members ORDER BY name ASC')->fetchAll(PDO::FETCH_ASSOC);
    $issues  = $pdo->query('SELECT id, book_id, book_title, author, member_id, member_name, issue_date, due_date, status, renewals, return_date, `condition` FROM issues ORDER BY issue_date DESC')->fetchAll(PDO::FETCH_ASSOC);

    ob_end_clean(); /* discard any PHP notices that crept into the buffer */
    echo json_encode([
        'success' => true,
        'books'   => $books,
        'members' => $members,
        'issues'  => $issues
    ]);
    exit;
} catch (Exception $e) {
    ob_end_clean();
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    exit;
}
