<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

require_once 'db.php';

try {
    $db = new Database();
    $pdo = $db->getPDO();
    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'GET') {
        $stmt = $pdo->query('SELECT email, name FROM librarians ORDER BY created_at DESC');
        $librarians = $stmt->fetchAll(PDO::FETCH_ASSOC);

        ob_end_clean();


        echo json_encode(['success' => true, 'librarians' => $librarians]);
        exit;
    }

    $input = json_decode(file_get_contents('php://input'), true) ?: [];

    if ($method === 'POST') {
        $name = isset($input['name']) ? trim($input['name']) : '';
        $email = isset($input['email']) ? trim($input['email']) : '';
        $password = isset($input['password']) ? $input['password'] : '';

        if (!$name || !$email || !$password) {
            http_response_code(400);
            ob_end_clean();

            echo json_encode(['success' => false, 'message' => 'Name, email, and password are required']);
            exit;
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            http_response_code(400);
            ob_end_clean();

            echo json_encode(['success' => false, 'message' => 'Invalid email address']);
            exit;
        }

        $stmt = $pdo->prepare('SELECT email FROM librarians WHERE email = ?');
        $stmt->execute([$email]);
        if ($stmt->fetch(PDO::FETCH_ASSOC)) {
            http_response_code(409);
            ob_end_clean();

            echo json_encode(['success' => false, 'message' => 'A librarian with that email already exists']);
            exit;
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('INSERT INTO librarians (email, name, password) VALUES (?, ?, ?)');
        $stmt->execute([$email, $name, $hashedPassword]);

        ob_end_clean();


        echo json_encode(['success' => true, 'message' => 'Librarian created successfully']);
        exit;
    }

    if ($method === 'PATCH') {
        $email = isset($input['email']) ? trim($input['email']) : '';
        $name = isset($input['name']) ? trim($input['name']) : null;
        $newEmail = isset($input['newEmail']) ? trim($input['newEmail']) : null;
        $password = array_key_exists('password', $input) ? $input['password'] : null;

        if (!$email) {
            http_response_code(400);
            ob_end_clean();

            echo json_encode(['success' => false, 'message' => 'Existing email is required to update a librarian']);
            exit;
        }

        $stmt = $pdo->prepare('SELECT email FROM librarians WHERE email = ?');
        $stmt->execute([$email]);
        if (!$stmt->fetch(PDO::FETCH_ASSOC)) {
            http_response_code(404);
            ob_end_clean();

            echo json_encode(['success' => false, 'message' => 'Librarian not found']);
            exit;
        }

        $updates = [];
        $params = [];

        if ($name !== null && $name !== '') {
            $updates[] = 'name = ?';
            $params[] = $name;
        }

        if ($newEmail !== null && $newEmail !== '' && $newEmail !== $email) {
            if (!filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
                http_response_code(400);
                ob_end_clean();

                echo json_encode(['success' => false, 'message' => 'Invalid new email address']);
                exit;
            }
            $stmt = $pdo->prepare('SELECT email FROM librarians WHERE email = ?');
            $stmt->execute([$newEmail]);
            if ($stmt->fetch(PDO::FETCH_ASSOC)) {
                http_response_code(409);
                ob_end_clean();

                echo json_encode(['success' => false, 'message' => 'A librarian with the new email already exists']);
                exit;
            }
            $updates[] = 'email = ?';
            $params[] = $newEmail;
        }

        if ($password !== null && $password !== '') {
            $updates[] = 'password = ?';
            $params[] = password_hash($password, PASSWORD_DEFAULT);
        }

        if (count($updates) === 0) {
            http_response_code(400);
            ob_end_clean();

            echo json_encode(['success' => false, 'message' => 'Nothing to update']);
            exit;
        }

        $params[] = $email;
        $sql = 'UPDATE librarians SET ' . implode(', ', $updates) . ' WHERE email = ?';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        ob_end_clean();


        echo json_encode(['success' => true, 'message' => 'Librarian updated successfully']);
        exit;
    }

    if ($method === 'DELETE') {
        $email = isset($input['email']) ? trim($input['email']) : '';
        if (!$email) {
            http_response_code(400);
            ob_end_clean();

            echo json_encode(['success' => false, 'message' => 'Email is required to delete a librarian']);
            exit;
        }

        $stmt = $pdo->prepare('DELETE FROM librarians WHERE email = ?');
        $stmt->execute([$email]);

        ob_end_clean();


        echo json_encode(['success' => true, 'message' => 'Librarian deleted successfully']);
        exit;
    }

    http_response_code(405);
    ob_end_clean();

    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
} catch (Exception $e) {
    http_response_code(500);
    ob_end_clean();

    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
    exit;
}
