<?php
/**
 * BookTrack — Central Configuration
 * ─────────────────────────────────────────────────────────────────────────────
 * All sensitive credentials live here (or in environment variables).
 * NEVER commit this file to version control.
 * Add  api/config.php  to your .gitignore.
 *
 * Priority: environment variable → value defined below.
 * Set env vars on your server to avoid storing secrets in files at all.
 * ─────────────────────────────────────────────────────────────────────────────
 */

// ── Database ──────────────────────────────────────────────────────────────────
define('DB_HOST',    getenv('DB_HOST')    ?: 'localhost');
define('DB_NAME',    getenv('DB_NAME')    ?: 'booktrack');
define('DB_USER',    getenv('DB_USER')    ?: 'root');
define('DB_PASS',    getenv('DB_PASS')    ?: '');          // ← set your DB password
define('DB_CHARSET', getenv('DB_CHARSET') ?: 'utf8mb4');

// ── SMTP / Mailer ─────────────────────────────────────────────────────────────
define('SMTP_HOST',   getenv('SMTP_HOST')   ?: 'smtp.gmail.com');
define('SMTP_PORT',   (int)(getenv('SMTP_PORT')   ?: 587));   // 587 = TLS | 465 = SSL
define('SMTP_USER',   getenv('SMTP_USER')   ?: 'platoniansbooktrack@gmail.com');
define('SMTP_PASS',   getenv('SMTP_PASS')   ?: '');            // ← set your App Password here or via env
define('FROM_EMAIL',  getenv('FROM_EMAIL')  ?: 'platoniansbooktrack@gmail.com');
define('FROM_NAME',   getenv('FROM_NAME')   ?: 'BookTrack Library');
