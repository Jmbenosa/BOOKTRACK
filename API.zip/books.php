<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

require_once 'db.php';

try {
    $db = new Database();
    $pdo = $db->getPDO();
    $method = $_SERVER['REQUEST_METHOD'];

    $input = json_decode(file_get_contents('php://input'), true) ?: [];

    if ($method === 'POST') {
        /* Create new book */
        $isbn = isset($input['isbn']) ? trim($input['isbn']) : '';
        $title = isset($input['title']) ? trim($input['title']) : '';
        $author = isset($input['author']) ? trim($input['author']) : '';
        $category = isset($input['category']) ? trim($input['category']) : '';
        $shelf = isset($input['shelf']) ? trim($input['shelf']) : '';
        $copies = isset($input['copies']) ? intval($input['copies']) : 1;
        $available = isset($input['available']) ? intval($input['available']) : $copies;

        if (!$title || !$author) {
            http_response_code(400);
            ob_end_clean();

            echo json_encode(['success' => false, 'message' => 'Title and author are required']);
            exit;
        }

        $stmt = $pdo->prepare('INSERT INTO books (isbn, title, author, category, shelf, copies, available, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([$isbn, $title, $author, $category, $shelf, $copies, $available, 'Available']);

        ob_end_clean();


        echo json_encode(['success' => true, 'message' => 'Book added successfully', 'id' => $pdo->lastInsertId()]);
        exit;
    }

    if ($method === 'PATCH') {
        /* Update book */
        $id = isset($input['id']) ? intval($input['id']) : 0;
        if (!$id) {
            http_response_code(400);
            ob_end_clean();

            echo json_encode(['success' => false, 'message' => 'Book ID is required']);
            exit;
        }

        $updates = [];
        $params = [];

        if (isset($input['isbn'])) {
            $updates[] = 'isbn = ?';
            $params[] = trim($input['isbn']);
        }
        if (isset($input['title'])) {
            $updates[] = 'title = ?';
            $params[] = trim($input['title']);
        }
        if (isset($input['author'])) {
            $updates[] = 'author = ?';
            $params[] = trim($input['author']);
        }
        if (isset($input['category'])) {
            $updates[] = 'category = ?';
            $params[] = trim($input['category']);
        }
        if (isset($input['shelf'])) {
            $updates[] = 'shelf = ?';
            $params[] = trim($input['shelf']);
        }
        if (isset($input['copies'])) {
            $updates[] = 'copies = ?';
            $params[] = intval($input['copies']);
        }
        if (isset($input['available'])) {
            $updates[] = 'available = ?';
            $params[] = intval($input['available']);
        }
        if (isset($input['status'])) {
            $updates[] = 'status = ?';
            $params[] = trim($input['status']);
        }
        if (isset($input['is_lost'])) {
            $updates[] = 'is_lost = ?';
            $params[] = intval($input['is_lost']);
        }
        if (isset($input['is_damaged'])) {
            $updates[] = 'is_damaged = ?';
            $params[] = intval($input['is_damaged']);
        }

        if (count($updates) === 0) {
            http_response_code(400);
            ob_end_clean();

            echo json_encode(['success' => false, 'message' => 'Nothing to update']);
            exit;
        }

        $params[] = $id;
        $sql = 'UPDATE books SET ' . implode(', ', $updates) . ' WHERE id = ?';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        ob_end_clean();


        echo json_encode(['success' => true, 'message' => 'Book updated successfully']);
        exit;
    }

    if ($method === 'DELETE') {
        /* Delete book */
        $id = isset($input['id']) ? intval($input['id']) : 0;
        if (!$id) {
            http_response_code(400);
            ob_end_clean();

            echo json_encode(['success' => false, 'message' => 'Book ID is required']);
            exit;
        }

        $stmt = $pdo->prepare('DELETE FROM books WHERE id = ?');
        $stmt->execute([$id]);

        ob_end_clean();


        echo json_encode(['success' => true, 'message' => 'Book deleted successfully']);
        exit;
    }

    http_response_code(405);
    ob_end_clean();

    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
} catch (Exception $e) {
    http_response_code(500);
    ob_end_clean();

    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
    exit;
}
?>
