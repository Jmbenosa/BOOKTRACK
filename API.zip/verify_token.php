<?php
/**
 * Password Reset Token Verification
 * Verifies reset token and updates password
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');

require_once 'db.php';
require_once 'mailer.php';

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    $response['message'] = 'Method not allowed';
    ob_end_clean();

    echo json_encode($response);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$token = isset($input['token']) ? trim($input['token']) : '';
$newPassword = isset($input['password']) ? $input['password'] : '';

if (empty($token) || empty($newPassword)) {
    http_response_code(400);
    $response['message'] = 'Token and password are required';
    ob_end_clean();

    echo json_encode($response);
    exit;
}

if (strlen($newPassword) < 6) {
    http_response_code(400);
    $response['message'] = 'Password must be at least 6 characters long';
    ob_end_clean();

    echo json_encode($response);
    exit;
}

try {
    $db = new Database();
    $pdo = $db->getPDO();

    // Verify token exists and is not expired
    $stmt = $pdo->prepare("SELECT email FROM password_resets WHERE token = ? AND expiry > NOW() AND used = FALSE");
    $stmt->execute([$token]);
    $resetRecord = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$resetRecord) {
        http_response_code(400);
        $response['message'] = 'Invalid or expired reset token';
        ob_end_clean();

        echo json_encode($response);
        exit;
    }

    $email = $resetRecord['email'];
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

    // Update password in users table
    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE email = ?");
    $stmt->execute([$hashedPassword, $email]);

    // Also update librarians table if email exists there
    $stmt = $pdo->prepare("UPDATE librarians SET password = ? WHERE email = ?");
    $stmt->execute([$hashedPassword, $email]);

    // Mark token as used
    $stmt = $pdo->prepare("UPDATE password_resets SET used = TRUE WHERE token = ?");
    $stmt->execute([$token]);

    // Send confirmation email
    sendPasswordChangedEmail($email);

    $response['success'] = true;
    $response['message'] = 'Password reset successfully. You can now login with your new password.';
    http_response_code(200);

} catch(Exception $e) {
    http_response_code(500);
    $response['message'] = 'Server error: ' . $e->getMessage();
}

ob_end_clean();


echo json_encode($response);
?>
