<?php
/**
 * Password Reset Handler
 * Generates a reset token and sends it via email
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');

require_once 'db.php';
require_once 'mailer.php';

$response = ['success' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    $response['message'] = 'Method not allowed';
    ob_end_clean();

    echo json_encode($response);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$email = isset($input['email']) ? trim($input['email']) : '';

if (empty($email)) {
    http_response_code(400);
    $response['message'] = 'Email is required';
    ob_end_clean();

    echo json_encode($response);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    $response['message'] = 'Invalid email format';
    ob_end_clean();

    echo json_encode($response);
    exit;
}

try {
    $db = new Database();
    $pdo = $db->getPDO();

    // Check if user exists (check all user types)
    $stmt = $pdo->prepare("SELECT id, email FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        // Also check librarians table
        $stmt = $pdo->prepare("SELECT email FROM librarians WHERE email = ?");
        $stmt->execute([$email]);
        $librarian = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$librarian) {
            http_response_code(404);
            $response['message'] = 'No account found with this email';
            ob_end_clean();

            echo json_encode($response);
            exit;
        }
    }

    // Generate reset token
    $token = bin2hex(random_bytes(32));
    

    // Check if password_resets table exists, if not create it
    $pdo->exec("CREATE TABLE IF NOT EXISTS password_resets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(255) NOT NULL,
        token VARCHAR(255) NOT NULL UNIQUE,
        expiry DATETIME NOT NULL,
        used BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX(email),
        INDEX(token)
    )");

    // Store reset token
    $stmt = $pdo->prepare("INSERT INTO password_resets (email, token, expiry) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR))");
    $stmt->execute([$email, $token]);

    // Build reset link dynamically based on the current server host
    $scheme    = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host      = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $scriptDir = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])), '/');
    $resetLink = $scheme . '://' . $host . $scriptDir . '/reset.html?token=' . $token;
    $mailSent = sendResetEmail($email, $resetLink, $token);

    if ($mailSent) {
        $response['success'] = true;
        $response['message'] = 'Reset link sent to your email';
        http_response_code(200);
    } else {
        // Email send failed – most likely an SMTP misconfiguration.
        // Check the PHP error log and the SMTP credentials in api/mailer.php.
        $response['message'] = 'Failed to send reset email. '
            . 'Please check that SMTP credentials are configured correctly in api/mailer.php '
            . 'or contact the system administrator.';
        http_response_code(500);
    }

} catch(Exception $e) {
    http_response_code(500);
    $response['message'] = 'Server error: ' . $e->getMessage();
}

ob_end_clean();


echo json_encode($response);
?>
