<?php
/**
 * Database Connection
 * Credentials are loaded from api/config.php — do not hardcode them here.
 */

require_once __DIR__ . '/config.php';

class Database {
    private $host    = DB_HOST;
    private $db_name = DB_NAME;
    private $user    = DB_USER;
    private $pass    = DB_PASS;
    private $charset = DB_CHARSET;
    private $pdo;

    public function connect() {
        $dsn = 'mysql:host=' . $this->host . ';dbname=' . $this->db_name . ';charset=' . $this->charset;
        
        try {
            $this->pdo = new PDO($dsn, $this->user, $this->pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $this->pdo;
        } catch(PDOException $e) {
            die('Connection Error: ' . $e->getMessage());
        }
    }

    public function getPDO() {
        if (!$this->pdo) {
            $this->connect();
        }
        return $this->pdo;
    }
}
?>
