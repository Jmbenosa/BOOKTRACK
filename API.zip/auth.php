<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

require_once 'db.php';

$input = json_decode(file_get_contents('php://input'), true);
$email = isset($input['email']) ? trim($input['email']) : '';
$password = isset($input['password']) ? $input['password'] : '';
$role = isset($input['role']) ? trim(strtolower($input['role'])) : '';

if (!$email || !$password || !$role) {
    http_response_code(400);
    ob_end_clean();

    echo json_encode(['success' => false, 'message' => 'Email, password and role are required']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    ob_end_clean();

    echo json_encode(['success' => false, 'message' => 'Invalid email address']);
    exit;
}

try {
    $db = new Database();
    $pdo = $db->getPDO();
    $user = null;

    if ($role === 'superadmin') {
        $stmt = $pdo->prepare("SELECT email, name, role, password FROM users WHERE email = ? AND role = 'superadmin'");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user) {
            $stored = $user['password'] ?? '';
            if (!password_verify($password, $stored)) {
                $user = null; /* not authenticated */
            }
            if ($user) unset($user['password']);
        }
    } elseif ($role === 'librarian') {
        $stmt = $pdo->prepare("SELECT email, name, role, password FROM users WHERE email = ? AND role = 'librarian'");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user) {
            $stored = $user['password'] ?? '';
            if (!password_verify($password, $stored)) {
                $user = null;
            }
            if ($user) unset($user['password']);
        }

        if (!$user) {
            $stmt = $pdo->prepare("SELECT email, name, password FROM librarians WHERE email = ?");
            $stmt->execute([$email]);
            $lib = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($lib) {
                $stored = $lib['password'] ?? '';
                if (password_verify($password, $stored)) {
                    $user = ['email' => $lib['email'], 'name' => $lib['name'], 'role' => 'librarian'];
                }
            }
        }
    } elseif ($role === 'student') {
        $stmt = $pdo->prepare("SELECT email, name, role, password FROM users WHERE email = ? AND role = 'student'");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user) {
            $stored = $user['password'] ?? '';
            if (!password_verify($password, $stored)) {
                $user = null;
            }
            if ($user) unset($user['password']);
        }
    } else {
        http_response_code(400);
        ob_end_clean();

        echo json_encode(['success' => false, 'message' => 'Invalid role']);
        exit;
    }

    if (!$user) {
        http_response_code(401);
        ob_end_clean();

        echo json_encode(['success' => false, 'message' => 'Incorrect email or password']);
        exit;
    }

    ob_end_clean();


    echo json_encode([
        'success' => true,
        'email' => $user['email'],
        'name' => $user['name'] ?? '',
        'role' => $user['role']
    ]);
    exit;
} catch (Exception $e) {
    http_response_code(500);
    ob_end_clean();

    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
    exit;
}
