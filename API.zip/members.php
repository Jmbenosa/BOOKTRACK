<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

require_once 'db.php';

try {
    $db = new Database();
    $pdo = $db->getPDO();
    $method = $_SERVER['REQUEST_METHOD'];

    $input = json_decode(file_get_contents('php://input'), true) ?: [];

    if ($method === 'POST') {
        /* Create new member */
        $name = isset($input['name']) ? trim($input['name']) : '';
        $email = isset($input['email']) ? trim($input['email']) : '';
        $phone = isset($input['phone']) ? trim($input['phone']) : '';
        $type = isset($input['type']) ? trim($input['type']) : 'Student';
        $sid = isset($input['sid']) ? trim($input['sid']) : '';
        $grade = isset($input['grade']) ? trim($input['grade']) : '';
        $section = isset($input['section']) ? trim($input['section']) : '';
        $address = isset($input['address']) ? trim($input['address']) : '';

        if (!$name) {
            http_response_code(400);
            ob_end_clean();

            echo json_encode(['success' => false, 'message' => 'Member name is required']);
            exit;
        }

        /* Generate member reference in format LIB-YYYY-### (display only) */
        $year = date('Y');
        $stmt = $pdo->prepare("SELECT member_ref FROM members WHERE member_ref LIKE ? ORDER BY member_ref DESC LIMIT 1");
        $stmt->execute(['LIB-' . $year . '-%']);
        $lastMember = $stmt->fetch(PDO::FETCH_ASSOC);
        $maxNum = 0;
        if ($lastMember && preg_match('/LIB-\d+-(\d+)/', $lastMember['member_ref'], $matches)) {
            $maxNum = intval($matches[1]);
        }
        $newRef = 'LIB-' . $year . '-' . str_pad($maxNum + 1, 3, '0', STR_PAD_LEFT);

        $stmt = $pdo->prepare('INSERT INTO members (member_ref, name, email, phone, type, sid, grade, section, address, active, overdue, total_issued, join_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())');
        /* New members start with active = 0 (no active loans) */
        $stmt->execute([$newRef, $name, $email, $phone, $type, $sid, $grade, $section, $address, 0, 0, 0]);

        $newNumericId = $pdo->lastInsertId();
        ob_end_clean();

        echo json_encode(['success' => true, 'message' => 'Member added successfully', 'id' => $newNumericId, 'member_ref' => $newRef]);
        exit;
    }

    if ($method === 'PATCH') {
        /* Update member */
        $id = isset($input['id']) ? trim($input['id']) : '';
        if (!$id) {
            http_response_code(400);
            ob_end_clean();

            echo json_encode(['success' => false, 'message' => 'Member ID is required']);
            exit;
        }

        /* Allow passing either numeric id or member_ref */
        if (!ctype_digit($id)) {
            $stmt = $pdo->prepare('SELECT id FROM members WHERE member_ref = ? LIMIT 1');
            $stmt->execute([$id]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                http_response_code(404);
                ob_end_clean();

                echo json_encode(['success' => false, 'message' => 'Member not found']);
                exit;
            }
            $id = $row['id'];
        }

        $updates = [];
        $params = [];

        if (isset($input['name'])) {
            $updates[] = 'name = ?';
            $params[] = trim($input['name']);
        }
        if (isset($input['email'])) {
            $updates[] = 'email = ?';
            $params[] = trim($input['email']);
        }
        if (isset($input['phone'])) {
            $updates[] = 'phone = ?';
            $params[] = trim($input['phone']);
        }
        if (isset($input['type'])) {
            $updates[] = 'type = ?';
            $params[] = trim($input['type']);
        }
        if (isset($input['sid'])) {
            $updates[] = 'sid = ?';
            $params[] = trim($input['sid']);
        }
        if (isset($input['grade'])) {
            $updates[] = 'grade = ?';
            $params[] = trim($input['grade']);
        }
        if (isset($input['section'])) {
            $updates[] = 'section = ?';
            $params[] = trim($input['section']);
        }
        if (isset($input['address'])) {
            $updates[] = 'address = ?';
            $params[] = trim($input['address']);
        }
        if (isset($input['active'])) {
            $updates[] = 'active = ?';
            $params[] = intval($input['active']);
        }
        if (isset($input['overdue'])) {
            $updates[] = 'overdue = ?';
            $params[] = intval($input['overdue']);
        }
        if (isset($input['total_issued'])) {
            $updates[] = 'total_issued = ?';
            $params[] = intval($input['total_issued']);
        }

        if (count($updates) === 0) {
            http_response_code(400);
            ob_end_clean();

            echo json_encode(['success' => false, 'message' => 'Nothing to update']);
            exit;
        }

        $params[] = $id;
        $sql = 'UPDATE members SET ' . implode(', ', $updates) . ' WHERE id = ?';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        ob_end_clean();


        echo json_encode(['success' => true, 'message' => 'Member updated successfully']);
        exit;
    }

    if ($method === 'DELETE') {
        /* Delete member */
        $id = isset($input['id']) ? trim($input['id']) : '';
        if (!$id) {
            http_response_code(400);
            ob_end_clean();

            echo json_encode(['success' => false, 'message' => 'Member ID is required']);
            exit;
        }

        /* Allow passing either numeric id or member_ref */
        if (!ctype_digit($id)) {
            $stmt = $pdo->prepare('SELECT id FROM members WHERE member_ref = ? LIMIT 1');
            $stmt->execute([$id]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                http_response_code(404);
                ob_end_clean();

                echo json_encode(['success' => false, 'message' => 'Member not found']);
                exit;
            }
            $id = $row['id'];
        }

        $stmt = $pdo->prepare('DELETE FROM members WHERE id = ?');
        $stmt->execute([$id]);

        ob_end_clean();


        echo json_encode(['success' => true, 'message' => 'Member deleted successfully']);
        exit;
    }

    http_response_code(405);
    ob_end_clean();

    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
} catch (Exception $e) {
    http_response_code(500);
    ob_end_clean();

    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
    exit;
}
?>
